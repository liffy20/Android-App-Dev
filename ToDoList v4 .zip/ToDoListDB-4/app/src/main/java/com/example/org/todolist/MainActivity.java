package com.example.org.todolist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.org.todolist.domain.DatabaseHelper;


import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper = new DatabaseHelper(this);



    private static final String LOG_TAG = "ToDoApp";

    private ToDoListManager listManager;
    private ToDoItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView todoList = (ListView) findViewById(R.id.todo_list);

        listManager = new ToDoListManager(getApplicationContext());

        adapter = new ToDoItemAdapter(
                this,
                listManager.getList()
        );

        todoList.setAdapter(adapter);

        ImageButton addButton = (ImageButton) findViewById(R.id.add_item);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddButtonClick();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private void onAddButtonClick() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.add_item);

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton(
                R.string.ok,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        ToDoItem item = new ToDoItem(

                                input.getText().toString(),
                                false
                        );
                        listManager.addItem(item);


                        adapter.swapItems(listManager.getList());

                    }
                });

        builder.setNegativeButton(
                R.string.cancel,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        builder.show();
    }

    private class ToDoItemAdapter extends ArrayAdapter<ToDoItem> {

        private Context context;
        private List<ToDoItem> items;
        private LayoutInflater inflater;

        public ToDoItemAdapter(
                Context context,
                List<ToDoItem> items
        ) {
            super(context, -1, items);

            this.context = context;
            this.items = items;
            this.inflater = LayoutInflater.from(context);
        }

        public void swapItems(List<ToDoItem> items) {
            this.items = items;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return items.size();
        }





        @Override
        public View getView(int position, View convertView, ViewGroup parent) {



            final ItemViewHolder holder;

            if(convertView == null) {
             convertView = inflater.inflate(R.layout.to_do_item_layout, parent, false);

                holder = new ItemViewHolder();
                holder.itemDescription = (TextView) convertView.findViewById(R.id.item);
                holder.itemState = (CheckBox) convertView.findViewById(R.id.checkBox);


                convertView.setTag(holder);



            } else {
                holder = (ItemViewHolder) convertView.getTag();

            }

            ImageButton removeButton = (ImageButton) convertView.findViewById(R.id.remove_item);
            removeButton.setTag(items.get(position));

           holder.itemTimeStamp = (TextView) convertView.findViewById(R.id.timeStamp);




            holder.itemDescription.setText(items.get(position).getDescription());
            holder.itemState.setChecked(items.get(position).isComplete());



            holder.itemState.setTag(items.get(position));

           convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ToDoItem item = (ToDoItem) holder.itemState.getTag();

                    item.toggleComplete();
                    listManager.updateItem(item);
                 holder.itemTimeStamp.setText(GetRelativeTimePassed(item.getTimeStamp()));
                    notifyDataSetChanged();


                }
            });

            holder.itemState.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    ToDoItem item = (ToDoItem) holder.itemState.getTag();

                    item.toggleComplete();
                    listManager.updateItem(item);


                    notifyDataSetChanged();


                }
            });



            removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {



                    Object tag =v.getTag();

                    if(tag!=null)
                    {
                        items.remove(tag);

                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        String[] whereargs = new String[]  {String.valueOf(tag)};

                        db.delete(DatabaseHelper.ITEMS_TABLE, "description" + "=?" , whereargs);



                        notifyDataSetChanged();

                    }





                }
            });



            return convertView;
        }
    }



    CharSequence GetRelativeTimePassed (Long timeStamp) {

        CharSequence updateTimeString = DateUtils.getRelativeTimeSpanString(
                timeStamp, System.currentTimeMillis(), 0);

        return updateTimeString;

    }


    public static class ItemViewHolder {
        public TextView itemDescription;
        public CheckBox itemState;
        public TextView itemTimeStamp;
    }
}
