package com.example.org.todolist;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.example.org.todolist.domain.DatabaseHelper;

import java.util.ArrayList;

import java.util.List;

public class ToDoListManager {

    private DatabaseHelper dbHelper;

    public ToDoListManager(Context context) {

        dbHelper = DatabaseHelper.getInstance(context);
    }

    public List<ToDoItem> getList() {

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + DatabaseHelper.ITEMS_TABLE,
                null
        );

        List<ToDoItem> items = new ArrayList<>();

        if(cursor.moveToFirst()) {
            while(!cursor.isAfterLast()) {

                ToDoItem item = new ToDoItem(
                        cursor.getString(cursor.getColumnIndex("description")),
                        cursor.getInt(cursor.getColumnIndex("completed")) != 0,
                        cursor.getLong(cursor.getColumnIndex("_id")),
                        cursor.getLong(cursor.getColumnIndex("timeStamp"))

                );
                items.add(item);
                cursor.moveToNext();
            }
        }
        cursor.close();
        return items;
    }

    public void addItem(ToDoItem item) {

        ContentValues newItem = new ContentValues();
        newItem.put("description", item.getDescription());
        newItem.put("completed", item.isComplete());
        newItem.put("timeStamp", item.getTimeStamp());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.insert(DatabaseHelper.ITEMS_TABLE, null, newItem);
    }

    public void updateItem(ToDoItem item) {

        ContentValues editItem = new ContentValues();
        editItem.put("description", item.getDescription());
        editItem.put("completed", item.isComplete());
        editItem.put("timeStamp", item.getTimeStamp());

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String[] args = new String[] { String.valueOf(item.getId()) };

        db.update(DatabaseHelper.ITEMS_TABLE, editItem, "_id=?", args);
    }




}
