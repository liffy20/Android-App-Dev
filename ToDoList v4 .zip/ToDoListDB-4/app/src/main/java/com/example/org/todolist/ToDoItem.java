package com.example.org.todolist;

import java.util.Calendar;

public class ToDoItem {

    private String description;
    private boolean isComplete;
    private long id;
    private Long timeStamp;



    public ToDoItem(String description, boolean isComplete) {
        this(description, isComplete, -1);
    }

    public ToDoItem(String description,boolean isComplete,long id, Long timeStamp) {
        this.description = description;
        this.isComplete = isComplete;
        this.id = id;
        this.timeStamp = timeStamp;
    }

    public ToDoItem(String description,boolean isComplete,long id) {
        this.description = description;
        this.isComplete = isComplete;
        this.id = id;

        Calendar now = Calendar.getInstance();
        this.timeStamp = now.getTimeInMillis();
    }




    public String getDescription() {
        return description;
    }

    public boolean isComplete() {
        return isComplete;
    }

    public void toggleComplete() {
        isComplete = !isComplete;
    }

    public long getId() { return id; }

    @Override
    public String toString() {

        return getDescription();
    }



    public Long getTimeStamp(){
        return timeStamp;
    }
}
