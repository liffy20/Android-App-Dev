package com.example.danie.elonmuskquiz;

import android.provider.BaseColumns;

/**
 * Created by danie on 2018-03-30.
 */

public class Quiz implements BaseColumns {

    public static class ElonQuest implements BaseColumns {
        public static final String TABLE_QUESTION = "quest";
        // tasks Table Columns names
        public static final String _ID = "id";
        public static final String _QUESTION = "question";
        public static final String _ANSWER = "answer"; 
        public static final String _OPTIONA = "optiona"; 
        public static final String _OPTIONB = "optionb"; 
        public static final String _OPTIONC = "optionc"; 


    }
}