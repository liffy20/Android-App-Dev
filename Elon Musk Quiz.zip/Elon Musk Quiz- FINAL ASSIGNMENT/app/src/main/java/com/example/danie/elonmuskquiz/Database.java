package com.example.danie.elonmuskquiz;

/**
 * Created by danie on 2018-03-30.
 */

import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.danie.elonmuskquiz.QQuest;

import static com.example.danie.elonmuskquiz.Quiz.ElonQuest._ANSWER;
import static com.example.danie.elonmuskquiz.Quiz.ElonQuest._ID;
import static com.example.danie.elonmuskquiz.Quiz.ElonQuest._OPTIONA;
import static com.example.danie.elonmuskquiz.Quiz.ElonQuest._OPTIONB;
import static com.example.danie.elonmuskquiz.Quiz.ElonQuest._OPTIONC;
import static com.example.danie.elonmuskquiz.Quiz.ElonQuest._QUESTION;
import static com.example.danie.elonmuskquiz.Quiz.ElonQuest.TABLE_QUESTION;

public class Database extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "ElonQuizit";
    // tasks table name

    private SQLiteDatabase dbase;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        dbase = db;

        String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_QUESTION + " ( "
                + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + _QUESTION
                + " TEXT, " + _ANSWER + " TEXT, " + _OPTIONA + " TEXT, "
                + _OPTIONB + " TEXT, " + _OPTIONC + " TEXT)";
        db.execSQL(sql);
        addQuestions();
        //db.close();
    }

    private void addQuestions() {
        QQuest q1 = new QQuest("Elon Musk has been a citizen of three countries. Name those countries.", "South Africa, Canada, USA", "South Africa, Belgium, Japan", "Canada, USA, Chad", "South Africa, Canada, USA");
        this.addQuestion(q1);
        QQuest q2 = new QQuest("In 1995, after two days at Stanford University, Elon Musk dropped out of graduate school to join the Internet boom and to start his first online company. What company did he start at the age of 24?", "Facebook", "Zip2 Corporation", "NetworkNews.com", "Zip2 Corporation");
        this.addQuestion(q2);
        QQuest q3 = new QQuest("X.com was Elon Musk second venture into the Internet boom, but he eventually sold the company in July 2002 for $1.5 billion. What famous company is X.com now known as??", "Amazon", "Bitcoin", "Paypal", "Paypal");
        this.addQuestion(q3);
        QQuest q4 = new QQuest("Contrary to popular belief, Elon Musk was not the original founder of Tesla Motors. Who were the original founders?", "Jeff Bezos & Mark Zuckerberg", "Jimmy Wale & Bill Gates", "Martin Eberhard & Marc Tarpenning", "Martin Eberhard & Marc Tarpenning");
        this.addQuestion(q4);
        QQuest q5 = new QQuest("How many children does Elon Musk have?", "3", "5", "6", "5");
        this.addQuestion(q5);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
     

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTION);
        
        onCreate(db);
    }

   
    public void addQuestion(QQuest quest) {
        
        ContentValues values = new ContentValues();
        values.put(_QUESTION, quest.getQUESTION());
        values.put(_ANSWER, quest.getANSWER());
        values.put(_OPTIONA, quest.getOptionA());
        values.put(_OPTIONB, quest.getOptionB());
        values.put(_OPTIONC, quest.getOptionC());
        
        dbase.insert(TABLE_QUESTION, null, values);
    }

    public List<QQuest> RetrieveQuestions() {
       

	   List<QQuest> QuestionList = new ArrayList<QQuest>();
        
        String selectQuery = "SELECT  * FROM " + TABLE_QUESTION;
        dbase = this.getReadableDatabase();
        Cursor cursor = dbase.rawQuery(selectQuery, null);
       
        if (cursor.moveToFirst()) {
            do {
                QQuest quest = new QQuest();
                quest.setID(cursor.getInt(0));
                quest.setQUESTION(cursor.getString(1));
                quest.setANSWER(cursor.getString(2));
                quest.setOptionA(cursor.getString(3));
                quest.setOptionB(cursor.getString(4));
                quest.setOptionC(cursor.getString(5));
                QuestionList.add(quest);
            } while (cursor.moveToNext());
        }
 
        return QuestionList;
    }

    public int countem() {
        int count = 0;
        String selectQuery = "SELECT  * FROM " + TABLE_QUESTION;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        count = cursor.getCount();
        return count;

    }
}