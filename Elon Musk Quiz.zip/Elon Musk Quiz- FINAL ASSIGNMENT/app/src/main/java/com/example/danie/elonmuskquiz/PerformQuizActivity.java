package com.example.danie.elonmuskquiz;

/**
 * Created by danie on 2018-03-30.
 */

import java.util.List;
import android.os.Bundle;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.example.danie.elonmuskquiz.Database;

public class PerformQuizActivity extends AppCompatActivity  {

    List<QQuest> ListofQuestions;
    int mark=0;
    int questionid=0;
    QQuest CurrentQuestion;
    TextView questionwords;
    RadioButton radioa, radiob, radioc;
    Button NextButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.questions_quiz);
        Database db=new Database(this);
        ListofQuestions=db.RetrieveQuestions();
        CurrentQuestion=ListofQuestions.get(questionid);
        questionwords=(TextView)findViewById(R.id.textView1);
        radioa=(RadioButton)findViewById(R.id.radio0);
        radiob=(RadioButton)findViewById(R.id.radio1);
        radioc=(RadioButton)findViewById(R.id.radio2);
        NextButton=(Button)findViewById(R.id.button1);
        setQuestionView();
        NextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup grp=(RadioGroup)findViewById(R.id.radioGroup1);
                RadioButton answer=(RadioButton)findViewById(grp.getCheckedRadioButtonId());
                grp.clearCheck();
                
                if(CurrentQuestion.getANSWER().equals(answer.getText()))
                {
                    mark++;
                    Log.d("mark", "Your mark"+mark);
                }
                if(questionid<5){
                    CurrentQuestion=ListofQuestions.get(questionid);
                    setQuestionView();
                }else{
                    Intent intent = new Intent(PerformQuizActivity.this, Results.class);
                    Bundle b = new Bundle();
                    b.putInt("mark", mark); 
                    intent.putExtras(b); 
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.questions_quiz, menu);
        return true;
    }
    private void setQuestionView()
    {
        questionwords.setText(CurrentQuestion.getQUESTION());
        radioa.setText(CurrentQuestion.getOptionA());
        radiob.setText(CurrentQuestion.getOptionB());
        radioc.setText(CurrentQuestion.getOptionC());
        questionid++;
    }


}
