package com.example.danie.elonmuskquiz;

/**
 * Created by danie on 2018-03-30.
 */

public class QQuest {

    private int ID;
    private String QUESTION;
    private String OptionA;
    private String OptionB;
    private String OptionC;
    private String ANSWER;
    public QQuest()
    {
        ID=0;
        QUESTION="";
        OptionA="";
        OptionB="";
        OptionC="";
        ANSWER="";
    }
    public QQuest(String qUESTION, String oPTIONA, String oPTIONB, String oPTIONC,
                    String aNSWER) {

        QUESTION = qUESTION;
        OptionA = oPTIONA;
        OptionB = oPTIONB;
        OptionC = oPTIONC;
        ANSWER = aNSWER;
    }
    public int getID()
    {
        return ID;
    }
    public String getQUESTION() {
        return QUESTION;
    }
    public String getOptionA() {
        return OptionA;
    }
    public String getOptionB() {
        return OptionB;
    }
    public String getOptionC() {
        return OptionC;
    }
    public String getANSWER() {
        return ANSWER;
    }
    public void setID(int id)
    {
        ID=id;
    }
    public void setQUESTION(String qUESTION) {
        QUESTION = qUESTION;
    }
    public void setOptionA(String oPTIONA) {
         OptionA = oPTIONA;
    }
    public void setOptionB(String oPTIONB) {
       OptionB = oPTIONB;
    }
    public void setOptionC(String oPTIONC) {
        OptionC = oPTIONC;
    }
    public void setANSWER(String aNSWER) {
        ANSWER = aNSWER;
    }
}
