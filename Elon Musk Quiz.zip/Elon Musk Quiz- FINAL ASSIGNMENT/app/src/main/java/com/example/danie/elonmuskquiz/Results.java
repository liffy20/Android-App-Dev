package com.example.danie.elonmuskquiz;

/**
 * Created by danie on 2018-03-30.
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RatingBar;
import android.widget.TextView;



public class Results extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_results);
     
        RatingBar bar=(RatingBar)findViewById(R.id.ratingBar1);
        bar.setNumStars(5);
        bar.setStepSize(0.5f);
        TextView t=(TextView)findViewById(R.id.textResult);
        Bundle b = getIntent().getExtras();
        int mark= b.getInt("mark");
        bar.setRating(mark);
        switch (mark)
        {
            case 0: t.setText("Zero correct, Elon will not choose you for SpaceX Mission to Mars");
                break;
            case 1: t.setText("One correct, You should read as much as Elon does");
                break;
            case 2: t.setText("Two correct, Tesla will call you for recruitment");
                break;
            case 3: t.setText("Three correct, Elon is proud of you");
                break;
            case 4:t.setText("Four correct, you must be a genius like Elon!");
                break;
            case 5:t.setText("Perfect Score, Elon will personally call you later to congratulate you!");
                break;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.quiz_results, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this, PerformQuizActivity.class);
            startActivity(settingsIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }






}
