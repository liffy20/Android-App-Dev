package com.example.danie.loginscreen;


public class LoginManager {
    private String userName;
    private String password;
    private int failedattempt;

    public LoginManager(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public boolean hasValidCredentials () {
        return (userName.equals("admin") && password.equals("admin"));

    }
}

