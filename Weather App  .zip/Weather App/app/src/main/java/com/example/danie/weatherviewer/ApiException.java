package com.example.danie.weatherviewer;

/**
 * Created by danie on 2018-03-03.
 */

public class ApiException extends Exception {

    public ApiException(String message) {
        super(message);
    }
}
