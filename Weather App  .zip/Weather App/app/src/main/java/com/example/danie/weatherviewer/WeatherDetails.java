package com.example.danie.weatherviewer;

import android.os.Parcel;
import android.os.Parcelable;

public class WeatherDetails implements Parcelable {

    private int currentTemperature;
    private int highTemperature;
    private int lowTemperature;
    private int tomhighTemperature;
    private int tomlowTemperature;
    private String description;
    private String city;

    public WeatherDetails(
            int currentTemperature,
            int highTemperature,
            int lowTemperature,
            int tomhighTemperature,
            int tomlowTemperature,
            String description,
            String city
    ) {
        this.currentTemperature = currentTemperature;
        this.highTemperature = highTemperature;
        this.lowTemperature = lowTemperature;
        this.tomhighTemperature = tomhighTemperature;
        this.tomlowTemperature = tomlowTemperature;
        this.description = description;
        this.city = city;
    }

    public WeatherDetails(Parcel in) {
        this(
                in.readInt(),
                in.readInt(),
                in.readInt(),
                in.readInt(),
                in.readInt(),
                in.readString(),
                in.readString()
        );
    }

    public int getCurrentTemperature() {
        return currentTemperature;
    }

    public int getHighTemperature() {
        return highTemperature;
    }

    public int getLowTemperature() {
        return lowTemperature;
    }

    public int getTomHighTemperature() {
        return tomhighTemperature;
    }

    public int getTomLowTemperature() {
        return tomlowTemperature;
    }

    public String getDescription() {
        return description;
    }

    public String getCity() {
        return city;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int i) {
    dest.writeInt(getCurrentTemperature());
    dest.writeInt(getHighTemperature());
dest.writeInt(getLowTemperature());
        dest.writeInt(getTomHighTemperature());
        dest.writeInt(getTomLowTemperature());
dest.writeString(getDescription());
dest.writeString(getCity());
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator<WeatherDetails>(){

        @Override
        public WeatherDetails createFromParcel(Parcel source) {
            return new WeatherDetails(source);
        }

        @Override
        public WeatherDetails[] newArray(int i) {
            return new WeatherDetails[0];
        }
    };
}
