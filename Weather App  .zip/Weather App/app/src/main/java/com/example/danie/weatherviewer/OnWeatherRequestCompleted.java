package com.example.danie.weatherviewer;

/**
 * Created by danie on 2018-03-02.
 */

public interface OnWeatherRequestCompleted {

    void OnTaskCompleted(WeatherDetails details);
}
