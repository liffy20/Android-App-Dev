package com.example.org.todolist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = "ToDoApp";

    private ToDoListManager listManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView todoList = (ListView) findViewById(R.id.todo_list);

        listManager = new ToDoListManager(getApplicationContext());

        ToDoItemAdapter adapter = new ToDoItemAdapter(
            this,
            listManager.getList()
        );

        todoList.setAdapter(adapter);

        ImageButton addButton = (ImageButton) findViewById(R.id.add_item);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddButtonClick();
            }
        });


    }

    @Override
    protected void onPause() {
        super.onPause();
        listManager.saveList();
    }

    private void onAddButtonClick() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.add_item);

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton(
                R.string.ok,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ToDoItem item = new ToDoItem(
                                input.getText().toString(),
                                false
                        );
                        listManager.addItem(item);
                    }
                });

        builder.setNegativeButton(
                R.string.cancel,
                new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }





    private class ToDoItemAdapter extends ArrayAdapter<ToDoItem> {

        private Context context;
        private List<ToDoItem> items;


        public ToDoItemAdapter(
            Context context,
            List<ToDoItem> items
        ) {
            super(context, -1, items);

            this.context = context;
            this.items = items;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if(convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.
                        getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.to_do_item_layout, parent, false);
            }

            TextView textView = (TextView) convertView.findViewById(R.id.item);
            CheckBox checkbox = (CheckBox) convertView.findViewById(R.id.checkBox);

            ImageButton removeButton = (ImageButton) convertView.findViewById(R.id.remove_item);

            textView.setText(items.get(position).getDescription());
            checkbox.setChecked(items.get(position).isComplete());

            convertView.setTag(items.get(position));


            removeButton.setTag(items.get(position));




            removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {



                    Object tag =v.getTag();

                    if(tag!=null)
                    {
                        items.remove(tag);


                    }
                    notifyDataSetChanged();











                }
            });

            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ToDoItem item = (ToDoItem) v.getTag();
                    item.toggleComplete();
                    notifyDataSetChanged();

                }
            });






            return convertView;
        }
    }
}
