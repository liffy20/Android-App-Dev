package com.example.org.todolist;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ToDoListManager {

    private static final String APP_PREFERENCES = "todoapp";
    private static final String TODO_ITEMS = "itemslist";

    private List<ToDoItem> items;
    private SharedPreferences savedData;

    public ToDoListManager(Context context) {

        savedData = context.getSharedPreferences(
            APP_PREFERENCES,
            Context.MODE_PRIVATE
        );

        String json = savedData.getString(TODO_ITEMS, null);

        if(json == null) {
            items = new ArrayList<>();
        } else {

            Type type = new TypeToken<List<ToDoItem>>() {}.getType();
            items = new Gson().fromJson(json, type);
        }
    }

    public List<ToDoItem> getList() {
       return items;
    }

    public void addItem(ToDoItem item) {

        items.add(item);
        saveList();
    }






    public void saveList() {
        SharedPreferences.Editor edit = savedData.edit();
        edit.clear();

        String json = new Gson().toJson(items);

        edit.putString(TODO_ITEMS, json);
        edit.apply();
    }
}
